
The PlayPokemon test application, PlayPokemon.html, can be launched directly from within current (NBNTest) folder.

After resizing the screen, you need to manually refresh the page.

When minimized, click on the top square button to display the search form.
