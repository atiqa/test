#!/bin/bash

case ${#} in [!3] ) 
    echo "usage: replaceToken.sh <input_file> <property_file> <output_file> " 1>&2
    exit 1 
   ;; 
esac

input_file=$1
property_file=$2
output_file=$3
declare -A map

while IFS='=' read -r key value
do
    map[$key]=$value
done < "$property_file"

while IFS= read line
do
	key=`echo $line | cut -d\[ -f3 | cut -d\] -f1`
	value=${map[$key]}
	cmnd="echo \"$line\" | sed -e 's/\[\[.*\]\]/$value/g'"
	s=`eval "$cmnd"`
	echo "$s"
done < $input_file > $output_file

