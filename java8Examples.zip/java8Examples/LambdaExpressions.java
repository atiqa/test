import java.util.function.*;

class LambdaExpressions {

	public static void testConsumer() {
		System.out.println("=====================================");
		System.out.println("testConsumer");
		Consumer<String> c = (x) -> System.out.println(x.toLowerCase());
		c.accept("Hello world!");
		
	}

	public static Supplier testSupplier() {
		System.out.println("=====================================");
		System.out.println("testSupplier");
		Supplier<String> s = () -> "This is a test";
		System.out.println("s=" + s.get());
		Supplier<LambdaExpressions> s1 = () -> new LambdaExpressions();
		s1.get().testUnaryOperator();
		s1.get().testBinaryOperator();		
		//System.out.println("s=" + s1.get().testSupplier());
		return s1;
	}

	public static void testBooleanSupplier() {
		System.out.println("=====================================");
		System.out.println("testBooleanSupplier");
		// BooleanSupplier bs = () -> testSupplier().get().testPredicate().test("yerfhsfegrf");
		BooleanSupplier bs = () -> testSupplier().get() instanceof LambdaExpressions;
		System.out.println("asBoolean()=" + bs.getAsBoolean());
	}
	public static void testFunction() {	
		System.out.println("=====================================");	
		System.out.println("testFunction");
		Function<String, Integer> f = (s) -> s.length();
		System.out.println("length=" + f.apply("yreureyre"));
	}

	public static Predicate testPredicate() {
		System.out.println("=====================================");
		System.out.println("testPredicate");
		Predicate<String> p = (s) -> s.length() > 10;
		Boolean b = p.test(("sdfhdfdfdgdkfghfgf"));

		System.out.println("b=" + b);
		b = p.test(("dsdsd"));

		System.out.println("b=" + b);
		return p;
	}

	public static void testUnaryOperator() {
		System.out.println("=====================================");
		System.out.println("testUnaryOperator");
		UnaryOperator<Integer> negate = (operand) -> operand * -1;
		System.out.println("V(300)=" + negate.apply(300));
	}

	public static void testBinaryOperator() {
		System.out.println("=====================================");
		System.out.println("testBinaryOperator");
		BinaryOperator<Integer> bo = (o1, o2) -> o1  * o2;
		System.out.println("V(300, 40)=" + bo.apply(300, 40));
	}

	public static void testRemainingFunctionalInterfaces() {
		System.out.println("=====================================");
		System.out.println("testRemainingFunctionalInterfaces");
		BiConsumer<String, String> biConsumer = (x, y) -> {
			System.out.println(x);
			System.out.println(y);
    		};
    		biConsumer.accept("java2s.com", " tutorials");
		ObjDoubleConsumer<LambdaExpressions> i  = (s, d) -> System.out.println(s.toString(d)); 
		i.accept(new LambdaExpressions(), 0.1234);
	}

	public void testScope() {
		System.out.println("=====================================");
		System.out.println("testScope");
		Function<String,String> func1 = x -> {System.out.println(this);return x ;};
		System.out.println(func1.apply("Hello"));
	}
static String z;
	public static void testCaptureVariables() {
		System.out.println("=====================================");
		System.out.println("testCaptureVariables");
		String y;
		y = " World";
		
		z = " World";
		Function<String, String> func1 = x -> {z = "Java";return x + y + z;};
		System.out.println(func1.apply("Hello"));
	}

	public static int factorial(int n) {
		return n == 0 ? 1 : factorial(n - 1) * n;
	}

	
	public static void testRecursive() {
		System.out.println("=====================================");
		System.out.println("testRecursive");
		Function<Integer, Integer> factorial = LambdaExpressions::factorial;
		System.out.println(factorial.apply(7));
	}
	public static void executeSupplyer(Supplier s) {
		System.out.println(s.get());
	}

	public static void testMethodInvocationContext() {
		System.out.println("=====================================");
		System.out.println("testMethodInvocationContext");
		executeSupplyer(() -> "I am a supplier");
	}

	public String toString(double d) {
		return "I am LambdaExpressions class" + d;
	}

	@FunctionalInterface
	interface Processor {
		int getStringLength(String str);
	}

	@FunctionalInterface
	interface SecondProcessor {
		int noName(String str);
	}


	// Type Inference
	public static void testTypeInference() {
		System.out.println("=====================================");
		System.out.println("testTypeInference");
		Function<Integer, String> f1 = (i) -> "Hello " + i;
		Function<Integer, String> f2 = f1;
		System.out.println(f2.apply(420));

		Processor stringProcessor = (String str) -> str.length();
		SecondProcessor secondProcessor = (String str) -> str.length();
		String name = "Java Lambda";
		int length = stringProcessor.getStringLength(name);
		System.out.println(length);
	}


	public static void main(String[] args) {
		testPredicate();
		testConsumer();
		Supplier s = testSupplier();
		testFunction();
		testBooleanSupplier();
		testRemainingFunctionalInterfaces();
		Boolean b = testSupplier().get() instanceof LambdaExpressions;
		LambdaExpressions le = (LambdaExpressions) testSupplier().get();
		le.testScope();
		testCaptureVariables();
		testRecursive();
		testMethodInvocationContext();
		testTypeInference();
	}
}
