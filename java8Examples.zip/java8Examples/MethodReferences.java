import java.util.*;
import java.util.function.*;

class MethodReferences {

	public String hello(String name) {
		return "Hello " + name;
	}

	public static void testStaticMethodReference() {
		System.out.println("=====================================");
		System.out.println("testStaticMethodReference");
		List<Integer> list = Arrays.asList(1, 2, 3, 4);
		list.forEach(System.out::println);

		Consumer<String> c = System.out::println;
		c.accept("Hello world");
		List<String> list1 = Arrays.asList("AAAA", "BBBBB", "CCCC");
		list1.forEach(c);

		Function<Integer, Integer> func1  = Integer::valueOf;
		Function<String, Integer> func2  = Integer::valueOf;
		BiFunction<String, Integer,  Integer> func3  = Integer::valueOf;

		System.out.println(func1.apply(7)); 
		System.out.println(func2.apply("7")); 
		System.out.println(func3.apply("101010101010", 2));

		Function<String[], List<String>> f = Arrays::asList;
		String[] array = {"AAAA", "BBBBB", "CCCC"};
		f.apply(array).forEach(c);
		f.apply(new String[] {"aaaaa", "bbbb"}).forEach(c);
		
	}

	public static void testInstanceMethodReference() {
		System.out.println("=====================================");
		System.out.println("testInstanceMethodReference");
		Function<String, String> f1 = (new MethodReferences())::hello;
		System.out.println(f1.apply("world!"));
	}

	public static void testConstructorMethodReference() {
		System.out.println("=====================================");
		System.out.println("testConstructorMethodReference");
		Supplier<MethodReferences> s = MethodReferences::new;
		Function<String, String> f1 = s.get()::hello;
		System.out.println(f1.apply("world!"));

		IntFunction<int[]> arrayCreator2 = int[]::new;
		int[] intArray2 = arrayCreator2.apply(5); 
		System.out.println(Arrays.toString(intArray2));

		Function<Integer, String[]> s1 = String[]::new;
		String[] array = s1.apply(20);
		System.out.println("Len=" + array.length);
	}

	public static void testGenericMethodReference() {
		System.out.println("=====================================");
		System.out.println("testGenericMethodReference");
		Function<String[], List<String>> f = Arrays::<String>asList;
		String[] array = {"AAAA", "BBBBB", "CCCC"};
		f.apply(array).forEach(System.out::println);
	}


	public static void main(String[] args) {
		testStaticMethodReference();
		testInstanceMethodReference();
		testConstructorMethodReference();
		testGenericMethodReference();
	}

}
