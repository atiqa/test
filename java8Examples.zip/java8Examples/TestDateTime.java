import java.time.*;
import java.util.function.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.*;
class TestDateTime {
	public static void testLocalDateTime() {
		System.out.println("==================testLocalDateTime====================");
		LocalDateTime sdt = LocalDateTime.now();	
		System.out.println("sdt=" + sdt);
	}

	public static void testZonedDateTime() {
		System.out.println("==================testZonedDateTime====================");
		System.out.println("==================Default Zone ====================");
		ZonedDateTime zdt = ZonedDateTime.now();
		ZoneOffset offset = zdt.getOffset();	
		System.out.println("zdt=" + zdt + " offset=" + offset);
		System.out.println("==================Default Zone ====================");
		ZoneId landon = ZoneId.of("Europe/London");
		zdt = ZonedDateTime.now(landon);	
		System.out.println("zdt=" + zdt);	
		System.out.println("ldt=" + LocalDateTime.now(landon));
		LocalDateTime sdt = LocalDateTime.now();
		zdt = sdt.atZone(landon);
		offset = zdt.getOffset();
		System.out.println("zdt=" + zdt + " offset=" + offset);
		
	}

	public static void testAllZones() {
		Set<String> allZones = ZoneId.getAvailableZoneIds();
		List<String> zoneList = new ArrayList<String>(allZones);
		Collections.sort(zoneList);

		LocalDateTime dt = LocalDateTime.now();
		for (String s : zoneList) {
			ZoneId zone = ZoneId.of(s);
			ZonedDateTime zdt = dt.atZone(zone);
			ZoneOffset offset = zdt.getOffset();
			String out = String.format("%35s %10s%n", zone, offset);
			// System.out.println(out);
		}
	}
	public static void testAllZonesWithJava8() {
		System.out.println("==================testAllZonesWithJava8====================");
		Stream<String> allZones = ZoneId.getAvailableZoneIds().stream();
		allZones.filter(s -> s.contains("Australia")).forEach(System.out::println);
		allZones = ZoneId.getAvailableZoneIds().stream();
		System.out.println("==================testAllZonesWithJava8  findAny ====================");
		Optional<String> perth = allZones.filter(s -> s.contains("Australia/Perth")).findAny();
		if(perth.isPresent()) {
			System.out.println(perth.get());	
		}
	}

	public static void testLocalTime() {
		System.out.println("==================testZonedDateFormat====================");
		LocalTime lt = LocalTime.now();
		LocalTime ltz = LocalTime.now(ZoneId.of("Europe/London"));
		System.out.println("lt=" + lt + " ltz=" + ltz);
		System.out.println("ZoneId.systemDefault=" + ZoneId.systemDefault());
	}

	

	public static void testDateTimeFormat() {
		System.out.println("==================testZonedDateFormat====================");
		String ldStr = DateTimeFormatter.ISO_DATE.format(LocalDate.now());
		System.out.println(ldStr);
		String odtStr = DateTimeFormatter.ISO_DATE.format(OffsetDateTime.now());
		System.out.println(odtStr);
		String zdtStr = DateTimeFormatter.ISO_DATE.format(ZonedDateTime.now());
		System.out.println(zdtStr);
		DateTimeFormatter isoDtf = DateTimeFormatter.ISO_DATE;
		System.out.println("isdoDtf.format=" + isoDtf.format(ZonedDateTime.now()));
		ZonedDateTime zdt = ZonedDateTime.now();
		System.out.println("zdt.format(isoDtf)=" + zdt.format(isoDtf));

		LocalDate ld = LocalDate.now();
		ldStr = ld.format(DateTimeFormatter.ISO_DATE);
		System.out.println("Local  Date: " + ldStr);

		OffsetDateTime odt = OffsetDateTime.now();
		odtStr = odt.format(DateTimeFormatter.ISO_DATE);
		System.out.println("Offset  Datetime: " + odtStr);

		zdt = ZonedDateTime.now();
		zdtStr = zdt.format(DateTimeFormatter.ISO_DATE);
		System.out.println("Zoned  Datetime: " + zdtStr);
	}

	public static void testCustomDateTimeFormat() {
		System.out.println("==================testCustomDateTimeFormat====================");
		String pattern = "[MMM yy:MM:dd] [HH:mm:ss-a]";
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern(pattern);
		LocalDate ld = LocalDate.now();
		String ldStr = ld.format(dtf);
		System.out.println("ldStr=" + ldStr);
		// pattern = "HH:mm:ss-a";
		// dtf = DateTimeFormatter.ofPattern(pattern);
		LocalTime lt = LocalTime.of(16, 30, 5, 78899);
		System.out.println("lt=" + lt);
		ldStr = lt.format(dtf);
		System.out.println("ltStr=" + ldStr);

		ld = LocalDate.of(2014, Month.JUNE, 30);
		lt = LocalTime.of(17, 30, 12);
		LocalDateTime ldt = LocalDateTime.of(ld, lt);
		System.out.println("ldt=" + ldt);
	}

	public static void testClockAndInstant() {
		System.out.println("==================testClockAndInstant====================");
		Instant i = Instant.now();
		System.out.println("Instant=" + i);
		Clock newClock = Clock.fixed(i, ZoneId.systemDefault());    
		System.out.println("newClock.instant=" + newClock.instant());
	}

	public static void testDayMonthYear() {
		System.out.println("==================testDayMonthYear====================");
		Year y = Year.of(1967);
		System.out.println("y=" + y);
		System.out.println("y-5=" + y.minusYears(5));

		UnaryOperator<Integer> f = (i) -> {System.out.println("year=" + Year.of(i) + " is leap year?" + Year.of(i).isLeap() ); return i + 1;};
		Stream<Integer> si = Stream.iterate(2010, f).limit(10);
		si.forEach(System.out::println);

		UnaryOperator<String> g = (s) -> s + 5;
		Stream<String> ss = Stream.iterate("test", f).limit(10);
		// ss.forEach(System.out::println);
	}

	public static void testIterate() {
		System.out.println("===========testIterate================");
		UnaryOperator<Integer> f = (i) -> i + 6;
		Stream<Integer> si = Stream.iterate(1, f).limit(10);
		si.forEach(System.out::println);
		System.out.println("===========================");
		si = Stream.iterate(1, f).skip(5).limit(10);
		si.forEach(System.out::println);
	}
	

	public static void main(String[] args) {
		testLocalDateTime();
		testZonedDateTime();
		testAllZones();
		testAllZonesWithJava8();
		testLocalTime();
		testDateTimeFormat();
		testClockAndInstant();
		testCustomDateTimeFormat();
		testDayMonthYear();
	}
}
