import java.util.function.*;
import java.util.*;
import java.util.stream.*;
import java.util.regex.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

class TestStream {
	public static void executeStreamOperations() {
		System.out.println("===========executeStreamOperations================");
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 7);
		int sum = numbers.parallelStream()
			.filter(n -> n % 2  == 1)
			.map(n  -> n * n)
			.reduce(1, Integer::sum);
		System.out.println(sum);

		sum = numbers.stream()
			.filter(n -> n % 2  == 1)
			.map(n  -> n * n)
			.reduce(1, Integer::sum);
		System.out.println(sum);
	}

	public static void testReduce() {
		System.out.println("===========testReduce================");
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 7);
		Stream<Integer> si = numbers.stream();
		// int r = si.reduce(0, (n1, n2) -> n1 * n2);
		 int sum = si.reduce(0, (n1, n2) -> n1 + n2); 
		System.out.println(sum);
		si = numbers.stream();
		si = si.map(n -> 2 * n);
		si = si.map(n -> 2);
		System.out.println(si.reduce(1, Integer::sum));
		
	}
	public static void testIterate() {
		System.out.println("===========testIterate================");
		UnaryOperator<Integer> f = (i) -> i + 6;
		Stream<Integer> si = Stream.iterate(1, f).limit(10);
		si.forEach(System.out::println);
		System.out.println("===========================");
		si = Stream.iterate(1, f).skip(5).limit(10);
		si.forEach(System.out::println);
	}

	public static void testGenerate() {
		System.out.println("===========testGenerate================");
		Supplier<Double> f = Math::random;
		Stream<Double> si = Stream.generate(f).limit(10);
		si.forEach(System.out::println);
		System.out.println("=====================================");
		Stream.generate(new Random()::nextInt)
		.limit(5)
		.forEach(System.out::println);
	}

	public static void testMoreStreams() {
		System.out.println("===========testMoreStreams================");
		String str = "ABCDEFGH1234567abcdefgh";
		IntStream schar = str.chars();
		schar = schar.map(c -> Character.isDigit((char)c) ? 'N' : c + 1);
		schar.forEach(n ->  System.out.print((char)n));
		System.out.println("===========RegExp================");
		str = "a,b,c,d";
		Pattern.compile(",").splitAsStream(str).filter(c -> c.charAt(0) > 'a' && c.charAt(0) < 'z' ).forEach(System.out::println);
		System.out.println("===========Files================");
		Path p = Paths.get("Link");
		try(Stream<String> ss = Files.lines(p)) {
			ss.forEach(System.out::println);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		System.out.println("===========Walk directory================");
		Path dir = Paths.get(".");
		try(Stream<Path> sp = Files.walk(dir)) {
			sp.forEach(System.out::println);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		
	}
	public static void testStreamOperations() {
		System.out.println("===========testStreamOperations================");
		Arrays.stream(new String[] {"aaaa", "bbbb", "cccc", "dddd", "cccc", "eeee", "ffff", "gggg", "bbbb"}).distinct().forEach(System.out::println);
		List<String> list = Arrays.asList("A","B","C","D", "C");
 		System.out.println("===========findAny================");
		Optional<String> result = list.stream().filter(s -> "C".equals(s)).findAny();
 		if(result.isPresent()) {
			System.out.println("data=" + result.get());
		}
		System.out.println("r=" + result);
 		System.out.println("===========findFirst================");
		list = Arrays.asList("A","B","C","D", "C");
		result = list.stream().filter(s -> "C".equals(s)).findFirst();
 		if(result.isPresent()) {
			System.out.println("data=" + result.get());
		}
		System.out.println("r=" + result);
 		System.out.println("===========map================");
		Stream.of("XML", "Java",  "CSS")
		.map(name  ->  name.chars())
		.forEach(System.out::println);
 		System.out.println("===========flatMap================");
		Stream.of("XML", "Java",  "CSS")
		.map(name  ->  name.chars())
		.flatMap(intStream ->  intStream.mapToObj(n ->  (char)n))
		.forEach(System.out::println);
		System.out.println("===========flatMap Arrays================");
		Arrays.stream(new String[] {"XML", "Java",  "CSS"})
		.map(name  ->  name.chars())
		.flatMap(intStream ->  intStream.mapToObj(n ->  (char)n))
		.forEach(System.out::println);
		System.out.println("===========flatMap Arrays================");
	}

	public static void testFlatMap() {
		System.out.println("===========testWithoutFlatMap================");
		String[][][] record = new String[][][] {{{"AAA", "BBB", "CCC"}, {"aaa", "bbb", "ccc"}, {"111", "222", "333"}}, {{"DDD", "EEE", "FFF"}, {"ddd", "eee", "fff"}, {"444", "555", "666"}}};
		for(String[][] array1 : record) {
			for(String[] array2 : array1) {
				for(String str : array2) {	
					System.out.println(str);
				}
			}
		}
		System.out.println("===========testFlatMap================");
		// Stream<String[][]> stream = Arrays.stream(record);
		Arrays.stream(record).flatMap(array -> Arrays.stream(array)).flatMap(array -> Arrays.stream(array)).forEach(System.out::println);
	}

	public static void main(String[] args) {
		executeStreamOperations();
		testReduce();
		testIterate();
		testGenerate();
		testMoreStreams();
		testStreamOperations();
		testFlatMap();
	}

}
