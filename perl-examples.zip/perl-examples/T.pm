package T;
require Exporter;
@ISA = qw/Exporter/;
@EXPORT = qw/doCroak/;
@EXPORT = qw/doConfess/;
@EXPORT = qw/f, doConfess/;

use Carp;
use Carp qw(cluck);
use Carp qw(croak);

sub f {
   print "Start\n";
   warn "warn: Error in module!";
   carp "carp: Error in module!";
   cluck "cluck: Error in module!"; 
   die "die: Error in module!";
   print "End\n";
}

sub doCroak {
	print "doCroak started\n";
	croak "croak: Error in module!";
	print "doCroak completed\n";
}

sub doConfess {
	print "doConfess started\n";
	confess "confess: Error in module!";
	print "doConfess completed\n";
}

