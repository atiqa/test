#!/usr/bin/perl

=begin comment
This is all part of multiline comment.
You can use as many lines as you like
These comments will be ignored by the 
compiler until the next =cut is encountered.
=cut

$a = 10;
print "hello a=$a\n";

$var = << "EOF";
This is case of single quote so variable value will not be 
interpolated. For example value of a = $a
EOF
print "$var\n";

$str = "\QWelcome to tutorialspoint's family 1234 test test12 ";
print "$str\n";

$age = 25;             # An integer assignment
$name = "John Paul";   # A string 
$salary = 1445.50;     # A floating point
$name1 = 'John Paul';   # A string 

print "Age = $age\n";
print "Name = $name\n";
print "Name1 = $name1\n";
print "Salary = $salary\n";

@ages = (25, "30", '40', '11', 'xyz');             
@names = ("John Paul", "Lisa", "Kumar");

print "\$ages = @ages", " - ", @ages, "\n";
print "\$ages[0] = $ages[0]\n";
print "\$ages[1] = $ages[1]\n";
print "\$ages[2] = $ages[2]\n";
print "\$names[0] = $names[0]\n";
print "\$names[1] = $names[1]\n";
print "\$names[2] = $names[2]\n";

#print "\$ages[0]+\$ages[3] = $ages[0] + $ages[3]\n";
print "\$ages[0]+\$ages[3] = ",  $ages[0] + $ages[3], "\n" ;
print "\$ages[3]+\$ages[0] = ",  $ages[3] + $ages[0], "\n" ;
print "\$ages[1]+\$ages[2]+\$ages[4] = ",  $ages[1] + $ages[2] , $ages[4], "\n" ;

print "\n-----------------Hash------------------\n";
%data = ('John Paul', 45, 'Lisa', 30, 'Kumar', 40, 67, 89);
print "\%data=", %data, " with double quote = ", %data, "\n";
print "\$data{'John Paul'} = $data{'John Paul'}\n";
print "\$data{'Lisa'} = $data{'Lisa'}\n";
print "\$data{'Kumar'} = $data{'Kumar'}\n";
print "\$data{67} = $data{67}\n";


print "\n------------Array copy/size-----------------------\n";
@names = ('John Paul', 'Lisa', 'Kumar');

@copy = @names;
$size = @names;

print "Given names are : @copy\n";
print "Number of names are : $size\n";
print "\n----------------------------------\n";
$smile  = v9786;
$foo    = v102.111.111;
$martin = v77.97.114.116.105.110.99.6786; 
$junk = v1575.1578.1576.1577.1579;

print "smile = $smile\n";
print "foo = $foo\n";
print "martin = $martin\n";
print "junk = $junk\n";
print "#627=", 0x627, "\n";

print "\n----------------------------------\n";
print "File name ", __FILE__ . "\n";
print "Line Number " . __LINE__ ."\n";
print "Package " . __PACKAGE__ ."\n";

# they can not be interpolated
print "__FILE__", __LINE__, " __PACKAGE__\n";
print __FILE__, " ". __LINE__, " ",  __PACKAGE__, "\n";
print "\n----------------------------------\n";

@days = qw/Mon Tue Wed Thu Fri Sat Sun/;

print "@days\n";
print @days, "\n";
print %days, "\n";
print $days, "\n";
print "$days[0]\n";
print "$days[1]\n";
print "$days[2]\n";
print "$days[6]\n";
print "$days[-1]\n";
print "$days[-7]\n";
print "\n----------------------------------\n";

@var_10 = (1..10);
@var_20 = (10..20);
@var_abc = (a..z);
@var_AZ = (A..Z);

print "@var_10\n";   # Prints number from 1 to 10
print "@var_20\n";   # Prints number from 10 to 20
print "@var_abc\n";  # Prints number from a to z
print "@var_AZ\n";  # Prints number from a to z

@var_KS = @var_AZ[10..18];

print "@var_KS\n";  # Prints number from a to z
splice(@var_AZ, 12, 5, 3..8); 
print "After - @var_AZ\n";
print "\n----------------------------------\n";
@array = (1,2,3);
print "Size: ",scalar @array,"\n";
$array[50] = 4;
print "Size: ",scalar @array,"\n";
$size = @array;
$max_index = $#array;

print "Size:  $size\n";
print "Max Index: $max_index\n";

print "\n----------------------------------\n";

# create a simple array
@coins = ("Quarter","Dime","Nickel");
print "1. \@coins  = @coins\n";

# add one element at the end of the array
push(@coins, "Penny");
print "2. \@coins  = @coins\n";

# add one element at the beginning of the array
unshift(@coins, "Dollar");
print "3. \@coins  = @coins\n";

# remove one element from the last of the array.
pop(@coins);
print "4. \@coins  = @coins\n";

# remove one element from the beginning of the array.
shift(@coins);
print "5. \@coins  = @coins\n";

print "\n----------------------------------\n";
@days = qw/Mon Tue Wed Thu Fri Sat Sun/;

@weekdays = @days[3,4,5];
print "@days\n";
print "@weekdays\n";

print "\n----------------------------------\n";
# define Strings
$var_string = "Rain-Drops-On-Roses-And-Whiskers-On-Kittens";
$var_names = "Larry,David,Roger,Ken,Michael,Tom";

# transform above strings into arrays.
@string = split('-', $var_string);
@names  = split(',', $var_names);

print "$string[3]\n";  # This will print Roses
print "$names[4]\n---\n";   # This will print Michael
$[ = 1;
print "$string[3]\n";  # This will print Roses
print "$names[4]\n";   # This will print Michael

$string1 = join( '-', @string );
$string2 = join( ',', @names );

print "$string1\n";
print "$string2\n";

@sstring = sort(@string);
print "After: @sstring\n";

print "\n----------------------------------\n";
@numbers = (1,3,(4,5,6));

print "numbers = @numbers\n";

@odd = (1,3,5);
@even = (2, 4, 6);

@numbers = (@odd, @even);

print "numbers = @numbers\n";

@list = (5,4,3,2,1)[1..3];

print "Value of list = @list\n";
print "\n----------------------------------\n";

$data{'John Paul'} = 45;
$data{'Lisa'} = 30;
$data{'Kumar'} = 40;
print "data = ", %data, "\n";

%data = ('John Paul' => 45, 'Lisa' => 30, 'Kumar' => 40);
print "data = ", %data, "\n";

%str = (-JohnPaul => 80, -x => test, t => wall, p => flowchart);
print "str = ", %str, "\n";
print "v = ",$str{-JohnPaul}, "\n";
print "v = ",$str{-x}, "\n";
print "v = ",$str{t}, "\n";
print "\n-------------subset of str hash ---------------------\n";
@array = @str{-JohnPaul, t};

print "Array : @array\n";
print "\n----------------------------------\n";
print "str = ", %str, "\n";
@keys = keys %str;

print "$keys[0]\n";
print "$keys[1]\n";
print "$keys[2]\n";
print "$keys[3]\n";
print "\n------------Keys----------------------\n";
print "data = ", %data, "\n";
@keys = keys %data;

print "$keys[0]\n";
print "$keys[1]\n";
print "$keys[2]\n";
print "$keys[3]\n";
print "\n--------------Values--------------------\n";
@values = values %data;

print "$values[0]\n";
print "$values[1]\n";
print "$values[2]\n";
print "$values[3]\n";
print "\n--------------exists--------------------\n";
$exists = exists($data{'Lisa'} );
print "exists = ", $exists, "\n";

if( exists($data{'Lisa'} ) ) {
   print "Lisa is $data{'Lisa'} years old\n";
} else {
   print "I don't know age of Lisa\n";
}

print "\n--------------hash size--------------------\n";
$size = @keys;
print "Hash size:  is $size\n";

print "\n--------------hash add/remove -------------------\n";
$data{'Ali'} = 55;
delete $data{'Lisa'};
print "data = ", %data, "\n";

print "\n--------------hash/array-------------------\n";

%skills = (-lang => [Java, Perl, C], -Db => [Oracle, MySQL]);
#%skills = (-lang => lang, -Db => MySQL);
@lang = "$skills{-lang}";
print "skills = ", %skills, "\n";
print "lang[1] = ", $skills{-lang}[2], "\n";













