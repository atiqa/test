#!/usr/bin/perl
print "\n--------------hash/array-------------------\n";

@colors = ["Blue", "Green", "Red"];
@list = [Apple, Orange, Pear];
%skills = (-lang => [Java, Perl, C], -Db => [Oracle, MySQL], -Fruit => @list, -Colors => @colors, -Days => [MON, TUE, WED, THU, FRI]);
#%skills = (-lang => lang, -Db => MySQL);
@lang = @{$skills{-lang}};
@db = @{$skills{-Db}};
@fruit = @{$skills{-Fruit}};
@colorList = @{$skills{-Colors}};
@days = @{$skills{-Days}};
print "skills = ", %skills, "\n";
print "lang[1] = ", $skills{-lang}[1], "\n";
print "Fruit[1] = ", $skills{-Fruit}[1], "\n";
print "list = ", $list[0][1], "\n";
print "lang[0] = ", $lang[0], "\n";
print "db[1] = ", $db[1], "\n";
print "fruit[1] = ", $fruit[1], "\n";
print "colorList[1] = ", $colorList[1], "\n";
print "days[1] = ", $days[1], "\n";


print "\n--------------OUTER: while ... INNER:while -------------------\n";
$a = 0;
OUTER:

 while( $a < 4 ) {
   $b = 0;
   print "value of a: $a\n";
   INNER:while ( $b < 4) {
      if( $a == 2) {
         $a = $a + 1;
         # jump to outer loop
         next OUTER;
      }
      $b = $b + 1;
      print "Value of b : $b\n";
   }
   print "\n";
   $a = $a + 1;
}
print "\n--------------OUTER: while ... INNER:while -------------------\n";
$a = 0;
OUTER: while( $a < 4 ) {
   $b = 0;
   print "value of a: $a\n";
   INNER:while ( $b < 4) {
      if( $a == 2) {
         # terminate outer loop
         last INNER;
      }
      $b = $b + 1;
      print "Value of b : $b\n";
   }
   print "\n";
   $a = $a + 1;
}
print "\n--------------while ... continue ... -------------------\n";
$a = 0;
while($a < 3) {
   print "Value of a = $a\n";
} continue {
   $a = $a + 1;
}

$a = 0;
while($a < 3) {
   print "Value of a = $a\n";
   $a = $a + 1;
}
print "\n--------------foreach ... continue ... -------------------\n";

@list = (1, 2, 3, 4, 5);
foreach $a (@list) {
   print "Value of a = $a\n";
} continue {
   last if $a == 4;
}
print "\n--------------while ... redo ... -------------------\n";
$a = 0;
while($a < 10) {
   if( $a == 5 ) {
      $a = $a + 1;
      redo;
   }
   print "Value of a = $a\n";
} continue {
   $a = $a + 1;
} 

print "\n--------------while ... next ... -------------------\n";
$a = 0;
while($a < 10) {
   if( $a == 5 ) {
      $a = $a + 1;
      next;
   }
   print "Value of a = $a\n";
} continue {
   $a = $a + 1;
} 
print "\n--------------while ... goto LABEL ... -------------------\n";
$a = 10;

x:do {
   if( $a == 15) {
      # skip the iteration.
      $a = $a + 1;
      # use goto LABEL form
      goto x;
   }
   print "Value of a = $a\n";
   $a = $a + 1;
} while( $a < 20 );
print "\n-------------- Date/Time ... -------------------\n";
print "localtime()=", localtime(), "\n";
@months = qw( Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec );
@days = qw(Sun Mon Tue Wed Thu Fri Sat Sun);

($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime();
print "sec=", $sec, "\n";
print "isdst=", $isdst, "\n";
print "yday=", $yday, "\n";
print "wday=", $wday, "\n";
print "mon=", $mon, "\n";
print "$mday $months[$mon] $days[$wday]\n";
$t=3329111201185111;
($x, $y, $z) = localtime();
print "x=$x y=$y z=$z", "\n";

@dateTime = localtime();
print "sec=$dateTime[0] y=$y z=$z", "\n";

@dateTime = gmtime();
print "hour=$dateTime[2] minute=$dateTime[1]\n";
printf("%02d:%02d:%02d\n", $hour, $min, $sec);
printf("%02d:%02d:%2d\n", $hour, $min, $sec);
$epoc = time();

print "Number of seconds since Jan 1, 1970 - $epoc\n";

use POSIX qw(strftime);

$datestring = strftime "%a %b %e %H:%M:%S %Y", localtime;
printf("date and time - $datestring\n");

$datestring = strftime "%c", localtime;

printf("date and time - $datestring\n");

$datestring = strftime "%x %X", localtime;

printf("date and time - $datestring\n");

sub subroutine_name {
   body of the subroutine
}







