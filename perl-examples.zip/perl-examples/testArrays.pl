#!/usr/bin/perl


print "\n-------------- Arrays, Hashes  -------------------\n";
@x = (1, 2, 3);
@y = [1, 2, 3];

$m = @x;
$n = @y;
print $m, "\n";
print $n, "\n";

%hashOfArrays = ('a1', @x, 'a2', $y);

print "\n-------------- Hash Keys -------------------\n";
foreach $key (keys %hashOfArrays ) {
	print $key;
	print "\n";
}

print "\n-------------- Hash Values -------------------\n";
use UNIVERSAL 'isa';

print shift;
foreach $v (values %hashOfArrays ) {
	print $v;
	print "\n";

	if (isa($v, 'ARRAY')) {
		print "We've got an array!!\n";
	}
}

package Person;
sub new {
   my $class = shift;
   my $self = {
      _firstName => shift,
      _lastName  => shift,
      _ssn       => shift,
   };
   # Print all the values just for clarification.
   print "First Name is $self->{_firstName}\n";
   print "Last Name is $self->{_lastName}\n";
   print "SSN is $self->{_ssn}\n";
   bless $self, $class;
   return $self;
}
sub getFirstName {
   my( $self ) = @_;
   print $self, "\n";
   return $self->{_firstName};
}
package Student;
sub new {
	my ( $class, $firstName, $lastName, $ssn ) = @_;
	my $self = {
		_firstName => $firstName,
		_lastName  => $lastName,
		_ssn       => $ssn,
	};
   	# Print all the values just for clarification.
   	print "First Name is $self->{_firstName}\n";
   	print "Last Name is $self->{_lastName}\n";
   	print "SSN is $self->{_ssn}\n";
   	bless $self, $class;
   	return $self;
}

sub getFirstName {
   my( $self ) = @_;
   print $self, "\n";
   return $self->{_firstName};
}

$object = new Person( "Mohammad", "Saleem", 23234345);
# Get first name which is set using constructor.
$firstName = $object->getFirstName();

print "Before Setting First Name is : $firstName\n";
$object = new Student( "Atiq", "Arbabzada", 23234345);
# Get first name which is set using constructor.
$firstName = $object->getFirstName();

print "Before Setting First Name is : $firstName\n";
sub DESTROY {
   print "MyClass::DESTROY called\n";
}
print "\n--------------AUTOLOAD -------------------\n";

sub AUTOLOAD {
   print "AUTOLOAD invked\n";
   my $self = shift;
   my $type = ref ($self) || warn "$self is not an object";
   my $field = $AUTOLOAD;
   $field =~ s/.*://;


   print 'self=', $self, ' field=', $field, ' type=', $type, "\n";
   unless (exists $self->{$field}) {
      warn "$field does not exist in object/class $type";
   }
   if (@_) {
      return $self->($name) = shift;
   } else {
      return $self->($name);
   }
}



$firstName = $object->getFirstNameX();
x();




