#!/usr/bin/perl
print "\n--------------subroutnes-------------------\n";

# Function definition
sub Average {
   # get total number of arguments passed.
   $n = scalar(@_);
   $sum = 0;

   foreach $item (@_) {
      $sum += $item;
   }
   $average = $sum / $n;

   print "Average for the given numbers : $average\n";
}

# Function call
Average(10, 20, 30);

# Function definition
sub PrintList {
   my @list = @_;
   print "Given list is @_\n";
   print "p0=$list[0] p3=$list[3] p4=$list[4] p8=$list[8]\n";
}
$a = 10;
@b = (1, 25, 3, 4);

# Function call with list parameter
PrintList(hello, ' world ', "testing ", (a, b, c),$a, @b);

# Function definition
sub PrintHash {
   my (%hash) = @_;

   foreach my $key ( keys %hash ) {
      my $value = $hash{$key};
      print "$key : $value\n";
   }
}
%hash = (name => Tom, 'age' => 19);

# Function call with hash parameter
PrintHash(%hash);
print "\n--------------References-------------------\n";
# Function definition
sub PrintHash {
   my (%hash) = @_;
   
   foreach $item (%hash) {
      print "Item : $item\n";
   }
   print "keys\n";
   foreach $key (keys %hash) {
      print "Item : $key\n";
   }
   print "values\n";
   foreach $v (values %hash) {
      print "Item : $v\n";
   }
}
%hash = ('name' => 'Tom', 'age' => 19);

# Create a reference to above function.
$cref = \&PrintHash;

# Function call using reference.
&$cref(%hash);
 print "\n--------------Circular References-------------------\n";
 my $foo = 100;
 $foo1 = \$foo;

 print "Value of foo is : ", $$foo1, "\n";
$arrayref = [a,b,c,[1,2,3,[a1, b2, c3]],d];
 print "\n-------------- First array -------------------\n";
foreach $x (@$arrayref) {
	print "x=$x\n";
}
$x = @$arrayref[2];
print "a=$x\n";
print "\n-------------- First inner array -------------------\n";
foreach $x (@{@$arrayref[3]}) {
	print "x=$x\n";
}

print "\n-------------- Second inner array -------------------\n";
foreach $x (@{@{@$arrayref[3]}[3]}) {
	print "x=$x\n";
}
print "\n---------------------------------------------------------------------------------------\n";
@array = (a,b,c,[1,2,3,[a1, b2, c3]],d);
foreach $x (@array) {
	print "x=$x\n";
}

print "\n-------------- First inner array -------------------\n";
foreach $x (@{@array[3]}) {
	print "x=$x\n";
}

print "\n-------------- Second inner array -------------------\n";
foreach $x (@{@{@array[3]}[3]}) {
	print "x=$x\n";
}

print "\n-------------- format -------------------\n";
format EMPLOYEE =
===================================
@<<<<<<<<<<<<<<<<<<<<<< @<< 
$name $age
@#####.##
$salary
===================================
.

select(STDOUT);
$~ = "EMPLOYEE";
write EMPLOYEE;

@n = ("Ali", "Raza", "Jaffer");
@a  = (20,30, 40);
@s = (2000.00, 2500.00, 4000.000);

$i = 0;
foreach (@n) {
   $name = $_;
   $age = $a[$i];
   $salary = $s[$i++];
   write;
}
