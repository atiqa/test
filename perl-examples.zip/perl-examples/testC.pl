#!/usr/bin/perl
print "\n-------------- File I/O -------------------\n";

print "Enter input\n";
@name = ('.', '..', testC.pl, '/tmp', '/home');


foreach $x (@name) {
	print "x=",$x;
	chomp $x;
	# my $file = __FILE__;

	my (@description, $size);

	if (-e $x) {
	   push @description, 'binary' if (-B _);
	   push @description, 'a socket' if (-S _);
	   push @description, 'a text file' if (-T _);
	   push @description, 'a block special file' if (-b _);
	   push @description, 'a character special file' if (-c _);
	   push @description, 'a directory' if (-d _);
	   push @description, 'executable' if (-x _);
	   push @description, (($size = -s _)) ? "$size bytes" : 'empty';
	   print "$x is ", join(', ',@description),"\n";
	}
	else {
		print "$x does not exist.";
	}
}

print "\n-------------- Directory listing -------------------\n";

$dir = "/home/atiq/*";
my @files = glob( $dir );

foreach (@files ) {
   print $_ ."\n";
}

print "\n-------------- Directory listing of current directory -------------------\n";
opendir (DIR, '.') or die "Couldn't open directory, $!";

while ($file = readdir DIR) {
   print "$file\n";
}
closedir DIR;

print "\n-------------- Modules -------------------\n";




use T;

doConfess();
doCroak();
f();
