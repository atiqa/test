#!/usr/bin/perl
print "\n-------------- Special characters -------------------\n";

foreach ('hickory','dickory','doc') {
   print $_;
   print "\n";
}
print "\n-------------- Special characters -------------------\n";
foreach ('hickory','dickory','doc') {
   print;
   print "\n";
}
print "\n-------------- \$ARG -------------------\n";
foreach ('hickory','dickory','doc') {
   print "$$";
   print "\n";
}
