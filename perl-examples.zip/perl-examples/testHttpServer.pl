#!/usr/bin/perl
print "\n-------------- Test HTTP Server -------------------\n";

use HTTP::Daemon;
  use HTTP::Status;
use HTTP::Response;
use HTTP::Headers;
use HTTP::Message;
  my $d = new HTTP::Daemon;
  print "Please contact me at: <URL:", $d->url, ">\n";
  while (my $c = $d->accept) {
      while (my $r = $c->get_request) {
          if ($r->method eq 'GET' and $r->url->path eq "/xyzzy") {
              # remember, this is *not* recommened practice :-)
              # $c->send_file_response("/etc/passwd");
		# $c->send_file_response("test.html");
$code = 200;
$header = new HTTP::Headers(Content-type => "text/html");
$msg = undef;
$content = "\n<html>\n<head>\n<meta charset=\"utf-8\">\n<title>Perl Tutorial</title>\n</head>\n<body>\n<h1>Perl Socket Programming</h1>\n</body>\n</html>\n";
$r = HTTP::Response->new( $code, $msg, $header, $content );

print "Sending response\n";

		$c->send_response($r);
print "Response sent\n";
          } else {
              $c->send_error(RC_FORBIDDEN);

          }
      }
      $c->close;
      undef($c);
  }
