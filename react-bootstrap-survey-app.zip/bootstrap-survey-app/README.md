To install and run the survey application you would need to install node.js first.

Please follow the instructions outline below to install and run the servey application.

Install the dependencies:
	cd react-survey-app
	npm install

Start the back-end server:
	cd react-survey-app/Server
	node Server.js
Run the application:
	cd react-survey-app
	npm start


